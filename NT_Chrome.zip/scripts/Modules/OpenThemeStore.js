//Create Theme selector----------------------------------------------------------------------------

function SelectTheme() {
     window.open("https://giscus.app/en/widget?callbyNewtube&repo=AzPepoze%2FNewtube&backLink=https%3A%2F%2Fazpepoze.github.io%2FNewtube-Web%2F&number=6")
 }
 
 function SelectThemeFloat() {
     chrome.runtime.sendMessage("OpenTheme")
     //window.open("https://giscus.app/en/widget?callbyNewtube&repo=AzPepoze%2FNewtube&backLink=https%3A%2F%2Fazpepoze.github.io%2FNewtube-Web%2F&number=6","Newtube Themes Store","directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,height=600,width=500")
 }