async function GetOneFileFromInput(Event) {
     return Event.target.files[0]
}